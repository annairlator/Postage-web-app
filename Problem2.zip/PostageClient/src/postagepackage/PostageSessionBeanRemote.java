/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package postagepackage;

import javax.ejb.Remote;

/**
 *
 * @author shaan
 */
@Remote
public interface PostageSessionBeanRemote {
    double calculate();
    public double getLength();
    public void setLength(double length);
    public double getWidth();
    public void setWidth(double width);
    public double getHeight();
    public void setHeight(double height);
    public double getWeight();
    public void setWeight(double weight);
    public double getZone();
    public void setZone(double zone);
}
